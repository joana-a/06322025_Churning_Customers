from flask import Flask, render_template, request, jsonify
import numpy as np
from tensorflow.keras.models import load_model
from sklearn.preprocessing import StandardScaler
import pickle

app = Flask(__name__)

# Load the pre-trained Keras model
# model = load_model('.h5')

# Load the scaler used during training
scaler = pickle.load(open("", "rb"))

encoder = pickle.load(open("", "rb"))


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Extract features from the form
        features = [float(request.form['TotalCharges']),
                    float(request.form['MonthlyCharges']),
                    int(request.form['tenure'])]

        # Normalize the features using the scaler
        normalized_features = scaler.transform([features])

        features = [float(request.form['TotalCharges']),
                    float(request.form['MonthlyCharges']),
                    int(request.form['tenure'])]
                    
        # Make prediction using the pre-trained model
        prediction = model.predict(normalized_features)

        # Convert the prediction to a human-readable format
        churn_prediction = "Churn" if prediction[0][0] > 0.5 else "No Churn"

        return render_template('result.html', prediction=churn_prediction)

if __name__ == '__main__':
    app.run(debug=True)
